
Shoe Store React App

About

This is a React application for an online shoe store where users can browse shoes and manage their shopping cart.

Technologies Used

React
JavaScript
JSX
CSS
React Hooks

Features

Displays different shoes with name, price and image
Allows users to add shoes to the shopping cart
Increases quantity when the same shoe is added again
Allows users to remove shoes from the cart
Displays shoe quantity and price
Calculates the total cost of items in the cart
Uses useState Hook to manage cart state

How to Run

Create a React project
Add the given code in App.jsx
Add styling in App.css
Open the terminal in the project folder
Run npm install
Run npm run dev
Open the local URL in your browser

Author

Yash