
import { useState } from "react";
import "./App.css";

function App() {
  const shoes = [
    {
      id: 1,
      name: "Nike Air Max",
      price: 2500,
      image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500"
    },
    {
      id: 2,
      name: "Adidas Ultraboost",
      price: 3000,
      image: "https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=500"
    },
    {
      id: 3,
      name: "Puma Running Shoes",
      price: 2000,
      image: "https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?w=500"
    },
    {
      id: 4,
      name: "New Balance",
      price: 3500,
      image: "https://images.unsplash.com/photo-1539185441755-769473a23570?w=500"
    },
    {
      id: 5,
      name: "Converse Sneakers",
      price: 1800,
      image: "https://images.unsplash.com/photo-1495555961986-6d4c1ecb7be3?w=500"
    },
    {
      id: 6,
      name: "Reebok Classic",
      price: 2200,
      image: "https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=500"
    }
  ];

  const [cart, setCart] = useState([]);

  const addToCart = (shoe) => {
    const existing = cart.find((item) => item.id === shoe.id);

    if (existing) {
      setCart(
        cart.map((item) =>
          item.id === shoe.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      );
    } else {
      setCart([...cart, { ...shoe, quantity: 1 }]);
    }
  };

  const removeFromCart = (id) => {
    setCart(
      cart
        .map((item) =>
          item.id === id
            ? { ...item, quantity: item.quantity - 1 }
            : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  const total = cart.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  return (
    <div className="container">
      <header>
        <h1>Shoe Store</h1>
        <p>Find Your Perfect Shoes</p>
      </header>

      <div className="main">
        <section className="products">
          <h2>Available Shoes</h2>

          <div className="shoe-list">
            {shoes.map((shoe) => (
              <div className="shoe-card" key={shoe.id}>
                <img src={shoe.image} alt={shoe.name} />
                <h3>{shoe.name}</h3>
                <p>₹{shoe.price}</p>
                <button onClick={() => addToCart(shoe)}>
                  Add to Cart
                </button>
              </div>
            ))}
          </div>
        </section>

        <section className="cart">
          <h2>Shopping Cart ({cart.reduce((sum, item) => sum + item.quantity, 0)})</h2>

          {cart.length === 0 ? (
            <p className="empty">Your cart is empty</p>
          ) : (
            cart.map((item) => (
              <div className="cart-item" key={item.id}>
                <div>
                  <h3>{item.name}</h3>
                  <p>₹{item.price}</p>
                  <p>Quantity: {item.quantity}</p>
                </div>

                <button onClick={() => removeFromCart(item.id)}>
                  Remove
                </button>
              </div>
            ))
          )}

          <div className="total">
            <h3>Total: ₹{total}</h3>
          </div>
        </section>
      </div>
    </div>
  );
}

export default App;
